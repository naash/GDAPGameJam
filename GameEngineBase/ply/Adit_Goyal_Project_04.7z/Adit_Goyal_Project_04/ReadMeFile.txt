By opening the solution and running it in Release mode,
the console option will show the loading of all three files 
if one of them is not present then Program will not continue


In this solution There are three files as was mentioned to be named as easy.xml,Medium.xml and hard.xml

OBJECTIVES->

1. A Xml file is generated containing four different languages and 20 different strings each as mentioned.

2. There is a main screen where user is prompted to press 1-4 for the language he wants to operate in.

3. The user can press 1-4 to change language at  any time and can see all the details about the program being run.

4. The user is prompted to choose one scene from three different xml files and also there is one main screen , 
second display shows the details of the Scene and 
also when "p" is pressed a third text display shows the greeting message 
along with the Status of being paused and 
also the instruction to continue the tool operation

5. When "P" is pressed the keys are halted and 
there is a message about how to continue and 
the screen is paused and 
this is shown in the language being used previously.  



The Summarised Keys are:::

1-3: On console for choosing the file to render
1-4: On graphical display about the language which can be selected by the user



* AWXD: Move camera around 
* S or s: To save The data At Any State 
* Q or q :To Quit After Closing The Display Screen 
* F or f: To cycle through Each Object to Access 
* I-K,i-k: Move object up and down Y -axis 
* J-L,j-l: Move Object Right Or left X-Axis 
* O-U,o-u: Move Object Forward And Backward to Z-Axis
* P-p: To pause the screen process