#pragma once
#include "pugixml.hpp"
#include "global.h"

class XmlUpdate
{
public:
	XmlUpdate();
	void CameraXmlUpdate();
	void SceneXmlUpdate();
	~XmlUpdate();

};

