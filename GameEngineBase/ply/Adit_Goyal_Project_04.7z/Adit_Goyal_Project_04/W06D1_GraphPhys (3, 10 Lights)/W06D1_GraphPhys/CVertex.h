#ifndef _CVertex_HG_
#define _CVertex_HG_

class CVertex
{
public:
	CVertex();
	virtual ~CVertex();
	float x, y, z;
};

#endif
