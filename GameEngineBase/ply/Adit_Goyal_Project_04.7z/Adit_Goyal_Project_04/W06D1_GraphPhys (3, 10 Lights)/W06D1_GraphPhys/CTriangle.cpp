#include "CTriangle.h"

CTriangle::CTriangle()
{
	this->V1 = this->V2 = this->V3 = 0;
	return;
}
